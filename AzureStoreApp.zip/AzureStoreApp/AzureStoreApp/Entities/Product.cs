﻿using System;
using System.Collections.Generic;
using Microsoft.WindowsAzure.Storage.Table;


namespace AzureStoreApp.Entities
{
    public class Product : TableEntity
    {
        public Product(string Vendor, int Id)
        {
            this.Vendor = Vendor;
            this.Id = Id;
            this.PartitionKey = Vendor;
            this.RowKey = "RK" + Id;
        }

        public Product() { }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Vendor { get; set; }
        public double Price { get; set; }
        public string ImageUrl { get; set; }
    }
}   