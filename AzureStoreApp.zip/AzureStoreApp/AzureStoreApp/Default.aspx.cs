﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Table;
using AzureStoreApp.Entities;

namespace AzureStoreApp
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=azstoragedeena;AccountKey=RipMvqxISgRfOZ+5veQ+/sxW/RCo6HP1njOU0Kr96H5zZL+ypjkpQnvJSc6/gvAa15m5wijDwzjHmVS3LoKZHQ==;EndpointSuffix=core.windows.net");

            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

            CloudTable table = tableClient.GetTableReference("Product");

            TableQuery<AzureStoreApp.Entities.Product> query = new TableQuery<AzureStoreApp.Entities.Product>();
            GridView1.DataSource = table.ExecuteQuery(query);
            GridView1.DataBind();
        }
    }
}