﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage.Table;
using AzureStoreApp.Entities;


namespace AzureStoreApp
{
    public partial class Product : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack && Request.QueryString.AllKeys.Contains("ProductID"))
            {
                tbId.Text = Request.QueryString["ProductID"];
                tbId.ReadOnly = true;
                tbVendor.Text = Request.QueryString["Vendor"];
                tbVendor.ReadOnly = true;

                CloudStorageAccount storageAccount = CloudStorageAccount.Parse("Storage Account Connection String");

                CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

                CloudTable table = tableClient.GetTableReference("Product");

                table.CreateIfNotExists();

                TableOperation retrieveOperation = TableOperation.Retrieve<AzureStoreApp.Entities.Product>(tbVendor.Text, "RK" + tbId.Text);
                TableResult retrievedResult = table.Execute(retrieveOperation);
                AzureStoreApp.Entities.Product product = (AzureStoreApp.Entities.Product)retrievedResult.Result;
                if (product != null)
                {
                    tbName.Text = product.Name;
                    tbPrice.Text = product.Price.ToString();
                    tbImageUrl.Text = product.ImageUrl;
                }
            }
        }

        protected async void btnUpload_Click(object sender, EventArgs e)
        {
            CloudStorageAccount storageAccount = new CloudStorageAccount(new StorageCredentials("azstoragedeena", "Key"), true);
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();

            CloudBlobContainer container = blobClient.GetContainerReference("deenafiles");
            await container.CreateIfNotExistsAsync();

            string strFilename = imgFileUpload.PostedFile.FileName.Substring(imgFileUpload.PostedFile.FileName.LastIndexOf('\\') + 1);

            CloudBlockBlob blockBlob = container.GetBlockBlobReference(strFilename);

            // Create or overwrite the "myblob" blob with contents from a local file.
            using (var fileStream = imgFileUpload.PostedFile.InputStream)
            {
                blockBlob.UploadFromStream(fileStream);
            }
            tbImageUrl.Text = "https://azstoragedeena.blob.core.windows.net/deenafiles/" + strFilename;

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse("Storage Account Connection String");

            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

            CloudTable table = tableClient.GetTableReference("Product");

            table.CreateIfNotExists();

            if (Request.QueryString.AllKeys.Contains("ProductID"))
            {
                //update
                TableOperation retrieveOperation = TableOperation.Retrieve<AzureStoreApp.Entities.Product>(tbVendor.Text, "RK"+tbId.Text);
                TableResult retrievedResult = table.Execute(retrieveOperation);
                AzureStoreApp.Entities.Product product = (AzureStoreApp.Entities.Product)retrievedResult.Result;
                if (product != null)
                {
                    product.Name = tbName.Text;
                    product.Price = Convert.ToDouble(tbPrice.Text);
                    product.ImageUrl = tbImageUrl.Text;
                    TableOperation updateOperation = TableOperation.Replace(product);
                    table.Execute(updateOperation);
                    lblMessage.Text = "Product update is done.";
                    Response.Redirect("Default.aspx");
                }
                else
                {
                    lblMessage.Text = "Product does not exist.";
                }

            }
            else
            {
                //create
                //TableBatchOperation batchOperation = new TableBatchOperation();
                AzureStoreApp.Entities.Product product = new AzureStoreApp.Entities.Product(tbVendor.Text, Convert.ToInt32(tbId.Text));
                product.Name = tbName.Text;
                product.Price = Convert.ToDouble(tbPrice.Text);
                product.ImageUrl = tbImageUrl.Text;
                TableOperation insertOperation = TableOperation.Insert(product);
                table.Execute(insertOperation);
                lblMessage.Text = "New Product creation is done.";
                Response.Redirect("Default.aspx");
            }
        }
    }
}